from rest_framework import viewsets, generics
from rest_framework.response import Response
from rest_framework import permissions
from rest_framework.views import APIView

from .permissions import IsOwnerOrReadOnly
from .serializer import *
from .models import *



class MyVideosAPI(APIView):
    def get(self, request, **kwargs):
        queryset = MyVideos.objects.all()
        serializer = MyVideosSerializer(queryset, many=True)
        return Response(serializer.data)


class PostList(generics.ListCreateAPIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrReadOnly]
    queryset = Post.objects.all()
    serializer_class = PostSerializer

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

class UserList(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAdminUser]