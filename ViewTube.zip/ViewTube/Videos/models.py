from django.db import models


class MyVideos(models.Model):
    title = models.CharField(max_length=100)
    cr_date = models.DateTimeField(auto_now_add=True)
    description = models.TextField()
    youtube_link = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return self.title



class Post(models.Model):
    # permission_classes = [permissions.IsAdminUser]
    title = models.CharField(max_length=100)
    cr_date = models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey('auth.User', related_name='posts', on_delete=models.CASCADE)
    description = models.TextField()
    youtube_link = models.CharField(max_length=200, null=True, blank=True)

    def upload_file(self, filename):
        path = f'videos/file/{filename}'
        return path

    def __str__(self):
        return self.title
