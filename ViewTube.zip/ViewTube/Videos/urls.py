from django.urls import path
from .views import *
from . import views


urlpatterns = [
    path('myvideo/', views.MyVideosAPI.as_view()),
    path('user/', UserList.as_view()),
    path('post/', PostList.as_view(), name='List'),
]