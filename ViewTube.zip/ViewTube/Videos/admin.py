from django.contrib import admin
from django.contrib.admin import ModelAdmin

from .models import *


class MyVideoAdmin(ModelAdmin):
    list_display = ['title', 'cr_date']

admin.site.register(MyVideos, MyVideoAdmin)
admin.site.register(Post)

